
public class __SHELL2 extends bluej.runtime.Shell {
public static void run() throws Throwable {

java.lang.String[] __bluej_param0 = { };
GameMain.main(__bluej_param0);

}}
