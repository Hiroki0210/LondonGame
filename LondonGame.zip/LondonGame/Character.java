import java.util.*;

/**
 * Enumeration class Character
 * A character in the game.
 * 
 * @author Hiroki Takahashi
 * @version 20/3/2018
 */
public enum Character
{
    LAURA("Laura", Item.SANDWICH, 0.5f),
    SALLY("Sally", Item.CRISPS, 0.5f), 
    ANDY("Andy", Item.DRINK, 0.5f),
    ALEX("Alex", null, 0.5f),
    COOKIEMONSTER("CookieMonster", null, 1.0f),
    CRISPGIVER("CrispGiver", null, 1.0f),
    PLAYER("Player", null, 0.0f);
    
    private String description;
    private Item item;
    private ArrayList<Item> items;
    private ArrayList<Character> characters;
    private static final double position = 0;
    private float moveProbability;
    /**
     * Constructor initialising description and item.
     */
    private Character(String desc, Item it, float probability)
    {
        description = desc;
        item = it;
        moveProbability = probability;
        items = new ArrayList<>();
        characters = new ArrayList<>();
        items.add(it);
    }
    
    /**
     * Return the description and description of item if it exists.
     */
    public String toString()
    {
        if (item == null) {
            return description;
        } else {
            return description + " having the item " + item.toString();
        }
    }
    
    /**
     * Take the given item from the character if it has that item.
     * Return whether item was taken.
     * @param The item to take away.
     * @returns true if the character had the item before the call.
     */
    public boolean take(Item it)
    {
        if (items.contains(it)) {
            items.remove(it);
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Receive the item from the character.
     * Return whether the item was received.
     * Returns true if the character doesn't have the item before the call
     */
    public boolean receive(Item e)
    {
        items.add(e);
        if (items.contains(e)) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Each character carry a list of items
     */
    public String getListItems()
    {
        return String.format("List: " + items);
    }
    
    /**
     * Returns the moveProbability
     */
    public float getProbability()
    {
        return moveProbability;
    }
    
    /**
     * This return true if and only the the moveProbability of the character is smaller than d.
     */
    public boolean autoMove(double d)
    {
        if (moveProbability < d)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /**
     * The CrispGiver gives Crisps to every character in the room.
     * The CookieMonster takes Crisps from every character in the room.
     */
    public void enterRoom(Room r)
    {
        Set<Character> cha = r.getCharacters();
        if(this.description == "CrispGiver")
        {
            //The CrispGiver gives Crisps to every character in the room.
            for (Character c : cha)
            {
                c.receive(item.CRISPS);
            }
        }
        boolean taken = false;
        if(this.description == "CookieMonster" && Item.CRISPS != null)
        {
            //The CookieMonster takes Crisps from every character in the room.
            for (Character c : cha)
            {
                c.take(Item.CRISPS);
                taken = true;
                if (taken == true)
                {
                    Character.COOKIEMONSTER.receive(item.CRISPS);
                }
            }
        }
        //Else do nothing
    }
}
