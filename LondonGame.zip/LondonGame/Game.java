import java.util.Set;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
/**
 *  This class is the central class of the "World of London" application. 
 *  "World of London" is a very simple, text based travel game.  Users 
 *  can walk around some scenery.
 * 
 * @author  Hiroki Takahashi
 * @version 20/03/2018
 */

public class Game 
{
    static private final int TIME_LIMIT = 12;
    private int time;
    private int move;
    private Set<Item> items;
    private Room currentRoom;
    private Room goalRoom;
    private boolean finished;
    private Character laura,sally,andy,alex,crispgiver,cookiemonster,player;
    private HashMap<Character, Room> characters;
   
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        finished = false;
        time = 0;
        items = new HashSet<>();
        createRooms();
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Room trafalgarSquare, chinatown, oxfordStreet, soho, coventGarden, 
        britishMuseum, stPancras, kingsCross, britishLibrary, leicesterSquare;

        // create the rooms
        trafalgarSquare = new Room("on Trafalgar Square");
        chinatown = new Room("in Chinatown");
        oxfordStreet = new Room("on Oxford Street");
        soho = new Room("in Soho");
        coventGarden = new Room("in Covent Garden");
        britishMuseum = new Room("in the British Museum");
        stPancras = new Room("in St Pancras");
        kingsCross = new Room("in Kings Cross");
        britishLibrary = new Room("in the British Library");
        leicesterSquare = new Room("on Leicester Square");

        // initialise room exits

        kingsCross.setExit(Direction.WEST, stPancras);
        stPancras.setExit(Direction.EAST, kingsCross);
        stPancras.setExit(Direction.WEST, britishLibrary);
        britishLibrary.setExit(Direction.EAST, stPancras);
        britishLibrary.setExit(Direction.SOUTH, britishMuseum);
        britishMuseum.setExit(Direction.NORTH, britishLibrary);
        britishMuseum.setExit(Direction.WEST, oxfordStreet);
        oxfordStreet.setExit(Direction.EAST, britishMuseum);
        britishMuseum.setExit(Direction.SOUTH, coventGarden);
        coventGarden.setExit(Direction.NORTH, britishMuseum);
        oxfordStreet.setExit(Direction.SOUTH, soho);
        soho.setExit(Direction.NORTH, oxfordStreet);
        soho.setExit(Direction.SOUTH, chinatown);
        chinatown.setExit(Direction.NORTH, soho);
        chinatown.setExit(Direction.SOUTH, leicesterSquare);
        leicesterSquare.setExit(Direction.NORTH, chinatown);
        leicesterSquare.setExit(Direction.EAST, coventGarden);
        coventGarden.setExit(Direction.WEST, leicesterSquare);
        leicesterSquare.setExit(Direction.SOUTH, trafalgarSquare);
        trafalgarSquare.setExit(Direction.NORTH, leicesterSquare);

        britishLibrary.addCharacter(Character.LAURA);
        oxfordStreet.addCharacter(Character.SALLY);
        leicesterSquare.addCharacter(Character.ANDY);
        trafalgarSquare.addCharacter(Character.ALEX);
        kingsCross.addCharacter(Character.CRISPGIVER);
        britishLibrary.addCharacter(Character.COOKIEMONSTER);
        //currentRoom.addCharacter(Character.PLAYER);
        
        laura = Character.LAURA;
        sally = Character.SALLY;
        andy = Character.ANDY;
        alex = Character.ALEX;
        crispgiver = Character.CRISPGIVER;
        cookiemonster = Character.COOKIEMONSTER;
        player = Character.PLAYER;
        
        characters = new HashMap<>();
        characters.put(laura,britishLibrary);
        characters.put(sally,oxfordStreet);
        characters.put(andy,leicesterSquare);
        characters.put(alex,trafalgarSquare);
        characters.put(crispgiver,kingsCross);
        characters.put(cookiemonster,britishLibrary);
        characters.put(player,currentRoom);
        
        currentRoom = stPancras;  // start game at St Pancras
        goalRoom = trafalgarSquare;
    }

    /**
     * Current time is within time limit.
     */
    public boolean inTime()
    {
        return 0 <= time && time <= TIME_LIMIT;
    }

    /**
     * Return whether the game has finished or not.
     */
    public boolean finished()
    {
        return finished;
    }

    /**
     * Opening message for the player.
     */
    public String welcome()
    {
        return "\nWelcome to the World of London!\n" +
        "World of London is a new travel game.\n" +
        currentRoom.getLongDescription() + "\n";
    }

    // implementations of user commands:
    /**
     * Give some help information.
     */
    public String help() 
    {
        return "You are lost. You are alone. You wander around foggy London.\n";
    }

    /** 
     * Try to go in one direction. If there is an exit, enter the new
     * room and return its long description; otherwise return an error message.
     * @param direction The direction in which to go.
     * Pre-condition: direction is not null.
     */
    public String goRoom(Direction direction) 
    {
        assert direction != null : "Game.goRoom gets null direction";

        time++;

        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            return "There is no exit in that direction!";
        }
        else {
            currentRoom = nextRoom;
            String result = look();
            if (currentRoom == goalRoom) {
                result += "\nCongratulations! You reached the goal of the game.\n";
                result += quit();
            } else if (!inTime()) {
                result += "\nYou ran out of time. You have lost.\n";
                result += quit();
            }
            return result;
        }
    }

    /** 
     * Try to go in random direction. If there is an exit, enter the new
     * room and return its long description; otherwise return an error message
     * Pre-condition: direction is not null.
     */
    public String goRandomRoom() 
    {
        time++;
        moveCharacters();
        
        Room nextRoom = currentRoom.randomExit();

        if (nextRoom == null) {
            return "There is no exit in that direction!";
        }
        else {
            currentRoom = nextRoom;
            String result = look();
            if (currentRoom == goalRoom) {
                result += "\nCongratulations! You reached the goal of the game.\n";
                result += quit();
            } else if (!inTime()) {
                result += "\nYou ran out of time. You have lost.\n";
                result += quit();
            }
            return result;
        }
    }    
    
    /**
     * Execute quit command.
     */
    public String quit()
    {
        finished = true;
        return "Thank you for playing.  Good bye.";
    }

    /**
     * Execute look command.
     */
    public String look()
    {
        return currentRoom.getLongDescription();
    }
    
    /**
     * Execute take command.
     * Pre-condition: item is not null.
     */
    public String take(Item item)
    {
        assert item != null : "Game.take gets null item";
        if (currentRoom.take(item)) {
            items.add(item);
            return "Item taken.";
        } else {
            return "Item not in this room.";
        }
    }
    
    /**
     * Execute eat command.
     */
    public String eat()
    {
        final Set<Item> meal = 
        new HashSet<>(Arrays.asList(Item.SANDWICH, Item.CRISPS, Item.CRISPS));
        if (items.containsAll(meal)) {
            return "Congratulations! You have won.\n" + quit();
        } else {
            return "You cannot eat yet.";
        }
    }
    
    /**
     * Makes all the characters(except for the player) move to random places when the player moves to another place.
     */
    public void moveCharacters()
    {
        Random rand = new Random();
        Room previousRoom, nextRoom;
        for (Character chars : characters.keySet())
        {
            if (chars.autoMove(rand.nextDouble()))
            {
                previousRoom = characters.get(chars);
                nextRoom = characters.get(chars).randomExit();
                previousRoom.removeCharacter(chars);
                nextRoom.addCharacter(chars);
                characters.put(chars,nextRoom);
                chars.enterRoom(nextRoom);
            }
        }
    }
}
